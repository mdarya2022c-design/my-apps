import os
import re
import shutil
import tempfile

from flask import Flask, jsonify, request, send_file, send_from_directory, after_this_request
from yt_dlp import YoutubeDL
from yt_dlp.utils import DownloadError

app = Flask(__name__, static_folder="static")

# Quality options shown in the UI -> yt-dlp format selectors.
# These avoid needing ffmpeg (single-file formats only).
FORMATS = {
    "best":  "best[ext=mp4]/best",
    "720p":  "best[height<=720][ext=mp4]/best[height<=720]/best",
    "480p":  "best[height<=480][ext=mp4]/best[height<=480]/best",
    "audio": "bestaudio[ext=m4a]/bestaudio",
}


def valid_url(url: str) -> bool:
    return bool(re.match(r"^https?://", url or ""))


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.post("/api/info")
def info():
    url = (request.json or {}).get("url", "").strip()
    if not valid_url(url):
        return jsonify(error="Enter a full link that starts with http:// or https://"), 400
    try:
        with YoutubeDL({"quiet": True, "noplaylist": True, "skip_download": True}) as ydl:
            data = ydl.extract_info(url, download=False)
    except DownloadError as e:
        return jsonify(error="Couldn't read that link. Check it and try again."), 400
    return jsonify(
        title=data.get("title"),
        thumbnail=data.get("thumbnail"),
        uploader=data.get("uploader"),
        duration=data.get("duration"),
    )


@app.get("/api/download")
def download():
    url = request.args.get("url", "").strip()
    quality = request.args.get("quality", "best")
    if not valid_url(url) or quality not in FORMATS:
        return jsonify(error="Invalid request"), 400

    tmp = tempfile.mkdtemp(prefix="dl_")
    opts = {
        "quiet": True,
        "noplaylist": True,
        "format": FORMATS[quality],
        "outtmpl": os.path.join(tmp, "%(title).80s.%(ext)s"),
    }
    try:
        with YoutubeDL(opts) as ydl:
            ydl.extract_info(url, download=True)
    except DownloadError:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify(error="Download failed. The site may block downloads."), 400

    files = os.listdir(tmp)
    if not files:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify(error="Nothing was downloaded."), 500
    path = os.path.join(tmp, files[0])

    @after_this_request
    def cleanup(response):
        shutil.rmtree(tmp, ignore_errors=True)
        return response

    return send_file(path, as_attachment=True, download_name=files[0])


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
