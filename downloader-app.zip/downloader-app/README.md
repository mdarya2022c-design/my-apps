# Downloader

A small web app: paste a link, choose a quality, download the file.
Built with Flask + yt-dlp.

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

Open http://localhost:5000

## Notes
- Audio/video are downloaded as single files, so ffmpeg is not required.
- Keep yt-dlp current: `pip install -U yt-dlp` (sites change often).
- Only download content you have the right to save.
